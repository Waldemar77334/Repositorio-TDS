var mes = 10
prompt("En que mes estamos?")
if("mes >=12;<=2"){
  alert("Es invierno")
}
if("mes >=3;<=5"){
  alert("Es primavera")
}
if("mes >=6;<=8"){
  alert("Es verano")
}
if(">=9;<=11"){
  alert("Es otoño")
}

prompt("Carlos Waldemar Alfaro Noriega 19005062")
